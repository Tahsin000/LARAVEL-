
<?php $__env->startSection('content'); ?>
<div class="row user-profile">
    <div class="col-lg-12 side-left">
        <div class="card mb-4">
        <div class="card-body avatar">
            <h2 class="card-title">Info</h2>
            <p class="name"><?php echo e(strtoupper($admin_profile_info->admin_name)); ?></p>
        </div>
        </div>
        <div class="card mb-4">
        <div class="card-body overview">
            <div class="wrapper about-user">
            <h2 class="card-title mt-4 mb-3">About</h2>
            <p>The information of Admin</p>
            </div>
            <!-- this class is Admin ID  -->  
            <div class="info-links">
                <a class="website">
                    <label class="icon-globe icon">ID: </label>
                    <span><?php echo e($admin_profile_info->admin_id); ?></span>
                </a>
            </div>
            <!-- this class is Admin phone  -->  
            <div class="info-links">
                <a class="website">
                    <label class="icon-globe icon">Phone: </label>
                    <span><?php echo e($admin_profile_info->admin_phone); ?></span>
                </a>
            </div>
            
        </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Downloads\my_project\resources\views/admin/profile.blade.php ENDPATH**/ ?>