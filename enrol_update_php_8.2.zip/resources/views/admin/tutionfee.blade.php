@extends('admin.layout')
@section('content')

<h1>Test of "Tutionfree"</h1>

@endsection